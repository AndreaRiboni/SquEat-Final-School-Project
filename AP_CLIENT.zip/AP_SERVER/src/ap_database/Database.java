package ap_database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Andrea Riboni
 */
public class Database {
    private static Connection conn;
    private static Statement query;
    private static PreparedStatement PrepQuery;
    private static ResultSet result;

    public Database() {
        try {
            conn = (Connection) DriverManager.getConnection("jdbc:mysql://tave.osdb.it:3306/c56_areaprogetto?user=c56_ribo&password=Az-72165");
            query = conn.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public ArrayList<String[]> stringify(ResultSet res) {
        try {
            int columns = result.getMetaData().getColumnCount();
            ArrayList<String[]> table = new ArrayList<>();
            while (result.next()) {
                String[] row = new String[columns];
                for (int i = 0; i < columns; i++) {
                    row[i] = result.getString(i + 1);
                }
                table.add(row);
            }
            return table;
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public ResultSet select(String query) {
        try {
            return Database.query.executeQuery(query);
        } catch (SQLException ex) {
            return null;
        }
    }

    public int count(ResultSet res) {
        try {
            res.last();
            return res.getRow();
        } catch (SQLException ex) {
            ex.printStackTrace();
            return 0;
        }
    }
}
